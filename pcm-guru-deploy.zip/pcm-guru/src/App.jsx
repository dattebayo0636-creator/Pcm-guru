import { useState, useRef, useEffect } from "react";

/* ══════════════════════════════════
   DATA — SUBJECTS + TEACHERS
══════════════════════════════════ */
const SUBJECTS = {
  phy: {
    id: "phy", name: "Physics", icon: "⚛️", hindiName: "Bhautiki",
    color: "#38bdf8", rgb: "56,189,248", g1: "#38bdf8", g2: "#0ea5e9",
    desc: "Mechanics, Electromagnetism, Quantum, Relativity aur bahut kuch",
    tag: "IIT-JEE · NEET · CBSE",
    topics: ["Laws of Motion","Work Energy","Electrostatics","Magnetism","Quantum","Thermodynamics","Waves & Optics","Modern Physics","Gravitation","Current Electricity","Relativity","Nuclear Physics"],
    topicIcons: ["⚙️","⚡","🔋","🧲","⚛️","🔥","🌊","☢️","🌍","💡","🌌","☣️"],
    actions: [{label:"📋 Formulas",q:"Important formulas list karo"},{label:"⚠️ Mistakes",q:"Common mistakes batao"},{label:"📝 Practice",q:"5 practice questions do"},{label:"💡 Concept",q:"Is topic ka core concept explain karo"}],
    hasLevels: false,
  },
  che: {
    id: "che", name: "Chemistry", icon: "🧪", hindiName: "Rasayan Vigyan",
    color: "#10b981", rgb: "16,185,129", g1: "#10b981", g2: "#059669",
    desc: "Organic, Inorganic, Physical — reactions se numericals tak",
    tag: "IIT-JEE · NEET · CBSE",
    topics: ["Mole Concept","Atomic Structure","Chemical Bonding","Thermodynamics","Equilibrium","Electrochemistry","Organic Basics","Hydrocarbons","Coordination","p-Block","d-f Block","Mechanisms"],
    topicIcons: ["⚖️","⚛️","🔗","🔥","⚗️","⚡","🌿","🛢️","💎","🧱","🔩","🔄"],
    actions: [{label:"⚗️ Reactions",q:"Reactions aur formulas list karo"},{label:"🔑 Concepts",q:"Key concepts explain karo"},{label:"⚠️ Mistakes",q:"Common mistakes batao"},{label:"📝 MCQs",q:"5 practice MCQs do"}],
    hasLevels: false,
  },
  mat: {
    id: "mat", name: "Mathematics", icon: "🔢", hindiName: "Ganit",
    color: "#f59e0b", rgb: "245,158,11", g1: "#f59e0b", g2: "#d97706",
    desc: "Calculus, Algebra, Trigonometry, Coordinate Geometry",
    tag: "IIT-JEE · CBSE · Boards",
    topics: ["Algebra","Trigonometry","Differentiation","Integration","Coord. Geometry","Vectors & 3D","Probability","Matrices","Complex Numbers","P & C","Sequences","Limits"],
    topicIcons: ["➕","📐","📉","📈","📍","🔀","🎲","🔢","💫","🔄","📊","∞"],
    actions: [{label:"📋 Formulas",q:"Saare formulas list karo"},{label:"📝 Example",q:"Solved example do step by step"},{label:"🎯 Practice",q:"5 practice problems do"},{label:"⚡ Shortcuts",q:"Tricks aur shortcuts batao"}],
    hasLevels: true,
  },
};

const TEACHERS = {
  phy: [
    {id:"nv",name:"NV Sir",org:"Vibrant Academy · Kota",emoji:"🎓",color:"#f97316",rgb:"249,115,22",g1:"#f97316",g2:"#ef4444",style:"Story-first, intuition, gold lines ✨",tag:"IIT-JEE · Kota",tagline:"Namaskar Students! 🙏 Physics Ki Duniya Mein Swagat!",welcome:"Pehle story, phir intuition, phir formula — real classroom jaisi padhai!",ph:"NV Sir se sawaal poochho...",qs:[["🍎","Newton ke laws real examples ke saath"],["⚡","Electromagnetic induction samjhao"],["⚛️","Quantum mechanics basics"],["🌌","Special Relativity simple mein"]],prompt:(l,c)=>`You are NV Sir AI inspired by Nitin Vijay of Vibrant Academy Kota. Start "Namaskar students! 🙏". Always story/analogy BEFORE formulas. "Dekho iska matlab...". Flow: STORY→INTUITION→CONCEPT→FORMULA→EXAMPLE→TRICK. "Yeh line GOLD hai! ✨". End "Samajh aaya? Brilliant! 🚀". **bold** key terms, \`code\` equations.${c}\nLANG:${l==="hi"?" Respond ENTIRELY in Hindi Devanagari. Physics terms stay English.":" Hinglish — Hindi phrases + English like NV Sir."}`},
    {id:"ninja",name:"Ninja Sir",org:"Vibrant Academy · Kota",emoji:"🥷",color:"#8b5cf6",rgb:"139,92,246",g1:"#8b5cf6",g2:"#6d28d9",style:"Fast-paced, intense, advanced ⚔️",tag:"IIT-JEE Advanced",tagline:"Ready ho? Chalte hain! ⚔️",welcome:"Fast-paced, intense. Physics ka DNA samjhao — IIT Advanced level!",ph:"Ninja Sir se advanced poochho...",qs:[["⚔️","Advanced mechanics problems"],["🔬","Wave optics deep dive"],["⚛️","Modern physics advanced"],["🧲","EM waves explain karo"]],prompt:(l,c)=>`You are Ninja Sir AI — intense advanced Physics from Vibrant Academy Kota. Start "Ready ho? Chalte hain! ⚔️". Direct — less story, more depth. Multiple approaches. "Yahan trap hai ⚠️". End "Crystal clear? Next level! 💥".${c}\nLANG:${l==="hi"?" ENTIRELY Hindi Devanagari.":" Fast intense Hinglish."}`},
    {id:"raj",name:"Rajwant Sir",org:"Physics Wallah",emoji:"📘",color:"#3b82f6",rgb:"59,130,246",g1:"#3b82f6",g2:"#2563eb",style:"Step-by-step clarity, calm 🧠",tag:"PW · Conceptual",tagline:"Ek ek step clear karenge! 📘",welcome:"Har concept clearly samjhaunga — baar baar padhne ki zarurat nahi!",ph:"Rajwant Sir se sawaal poochho...",qs:[["📘","Laws of Motion step by step"],["⚡","Current electricity"],["🔋","Electrostatics"],["🌊","Wave motion"]],prompt:(l,c)=>`You are Rajwant Sir AI from Physics Wallah. Start "Hello students! 👋". Systematic numbered steps. Calm patient. "PW ke students ke liye..." End "Bilkul clear! Koi confusion? 😊".${c}\nLANG:${l==="hi"?" ENTIRELY Hindi Devanagari.":" Calm clear Hinglish."}`},
    {id:"sal",name:"Saleem Sir",org:"Physics Wallah",emoji:"🌿",color:"#10b981",rgb:"16,185,129",g1:"#10b981",g2:"#059669",style:"Visual, friendly, NEET-focused 💡",tag:"PW · NEET",tagline:"Concept clear karo, NEET crack karo! 🌿",welcome:"Visually samjhaunga — NEET ke liye perfect approach!",ph:"Saleem Sir se sawaal poochho...",qs:[["🌿","Ray optics NEET ke liye"],["⚡","Alternating current"],["🧬","Modern physics MCQs"],["🔋","Capacitors detail mein"]],prompt:(l,c)=>`You are Saleem Sir AI from Physics Wallah NEET. Start "Hello students! 😊". VISUAL — describe diagrams. "NEET mein yeh aise aata hai...". Friendly encouraging. End "NEET mein zaroor aayega! 🌿".${c}\nLANG:${l==="hi"?" ENTIRELY Hindi Devanagari.":" Warm Hinglish."}`},
    {id:"alakh",name:"Alakh Sir",org:"Physics Wallah Founder",emoji:"🦁",color:"#ef4444",rgb:"239,68,68",g1:"#ef4444",g2:"#dc2626",style:"Motivational, zero-to-hero 💪",tag:"PW Founder",tagline:"Padhai karni hai toh dil se karo! 💪",welcome:"Ameer-gareeb ka koi fark nahi. Sirf mehnat ka fark hai!",ph:"Alakh Sir se poochho...",qs:[["💪","Newton laws motivational style"],["🦁","Physics easy kyun nahi lagti?"],["🔥","Electrostatics zero se hero"],["🌟","Exam strategy batao"]],prompt:(l,c)=>`You are Alakh Sir AI — Alakh Pandey PW founder. Start "Namaskar doston! 🙏". HIGHLY motivational. Simple language. "Ameer ho ya gareeb — Physics sabke liye same". End "Mehnat karo. Ek baar aur! 🔥".${c}\nLANG:${l==="hi"?" ENTIRELY Hindi Devanagari.":" Energetic Hinglish."}`},
  ],
  che: [
    {id:"vk",name:"VK Jaiswal Sir",org:"Allen / Unacademy",emoji:"🟢",color:"#10b981",rgb:"16,185,129",g1:"#10b981",g2:"#059669",style:"Inorganic king, memory tricks 🔑",tag:"IIT-JEE Inorganic",tagline:"Inorganic Chemistry easy karo! 🟢",welcome:"Har element ki chemistry story ki tarah — shortcuts ke saath!",ph:"VK Jaiswal Sir se Inorganic poochho...",qs:[["🟢","p-Block trends samjhao"],["🔑","Coordination compounds"],["⚗️","Chemical bonding shortcuts"],["📋","d-Block periodic trends"]],prompt:(l,c)=>`You are VK Jaiswal Sir AI — Inorganic Chemistry legend Allen/Unacademy. Start "Namaskar! 🟢". Memory TRICKS for everything. "JEE mein yeh topic se har saal question aata hai". End "Yeh trick exam mein zaroor kaam aayegi! 🚀".${c}\nLANG:${l==="hi"?" ENTIRELY Hindi Devanagari.":" Hinglish VK Jaiswal style."}`},
    {id:"na",name:"NA Sir",org:"Allen Kota",emoji:"⚗️",color:"#3b82f6",rgb:"59,130,246",g1:"#3b82f6",g2:"#2563eb",style:"Physical chemistry numericals 🔢",tag:"Allen Physical Chem",tagline:"Physical Chemistry — Numbers se daro mat! ⚗️",welcome:"Mole concept se thermodynamics tak — har numerical ek story hai!",ph:"NA Sir se Physical Chemistry poochho...",qs:[["⚗️","Mole concept problems"],["🔥","Thermodynamics first law"],["⚡","Electrochemistry numericals"],["⚖️","Equilibrium Kc Kp"]],prompt:(l,c)=>`You are NA Sir AI — Physical Chemistry Allen Kota numerical master. Start "Namaskar! Physical Chemistry mein dive! ⚗️". Step-by-step numericals. Show all units. End "Numerical clear? Variation try karo! 💪".${c}\nLANG:${l==="hi"?" ENTIRELY Hindi Devanagari.":" Logical Hinglish."}`},
    {id:"ms",name:"MS Chouhan Sir",org:"Allen Kota",emoji:"🔮",color:"#8b5cf6",rgb:"139,92,246",g1:"#8b5cf6",g2:"#6d28d9",style:"Organic mechanisms, reactions 🧬",tag:"Allen Organic",tagline:"Mechanisms samjho, reactions yaad hongi! 🔮",welcome:"Organic ek language hai — grammar samajh lo, sab reactions aayengi!",ph:"MS Chouhan Sir se Organic poochho...",qs:[["🔮","SN1 vs SN2 mechanism"],["🌿","Alkene reactions"],["💊","Alcohols phenols ethers"],["🧬","Named reactions"]],prompt:(l,c)=>`You are MS Chouhan Sir AI — Organic Chemistry Allen Kota. Start "Hello! Organic mein swagat! 🔮". Always explain MECHANISM step by step. "Mechanism samjho — reaction khud yaad ho jayegi". End "Mechanism clear? 🔮".${c}\nLANG:${l==="hi"?" ENTIRELY Hindi Devanagari.":" Mechanism-focused Hinglish."}`},
    {id:"paaras",name:"Paaras Sir",org:"Physics Wallah",emoji:"🌟",color:"#f97316",rgb:"249,115,22",g1:"#f97316",g2:"#ea580c",style:"Friendly, NEET focused 💡",tag:"PW NEET Chem",tagline:"Chemistry easy hai — sahi tarike se padho! 🌟",welcome:"Zero se samjhaunga — NEET ke liye perfect. Friendly, clear!",ph:"Paaras Sir se Chemistry poochho...",qs:[["🌟","Atomic structure NEET"],["💊","Biomolecules easy way"],["⚗️","Solutions colligative"],["🌿","Organic classification"]],prompt:(l,c)=>`You are Paaras Thakur Sir AI — PW Chemistry NEET. Start "Hello baccho! 🌟". Friendly encouraging. NEET-focused. Real-life examples. End "NEET mein zaroor aayega! 🌟".${c}\nLANG:${l==="hi"?" ENTIRELY Hindi Devanagari.":" Warm friendly Hinglish."}`},
    {id:"arvind",name:"Arvind Arora Sir",org:"Physics Wallah",emoji:"💎",color:"#06b6d4",rgb:"6,182,212",g1:"#06b6d4",g2:"#0891b2",style:"JEE clarity, visual 🎯",tag:"PW JEE Chem",tagline:"JEE Chemistry — Clarity se Cracking! 💎",welcome:"Crystal clear JEE Chemistry — visual + logical approach!",ph:"Arvind Arora Sir se JEE Chem poochho...",qs:[["💎","Chemical bonding advanced"],["⚡","Redox oxidation states"],["🔗","Coordination IUPAC"],["⚗️","Gaseous state numericals"]],prompt:(l,c)=>`You are Arvind Arora Sir AI — PW JEE Chemistry. Start "Hello! 💎 Crystal clear karte hain!". VISUAL approach. "3D mein socho". JEE-focused. End "Crystal clear? JEE ka koi twist solve! 💎".${c}\nLANG:${l==="hi"?" ENTIRELY Hindi Devanagari.":" Clear logical Hinglish."}`},
  ],
  mat: [
    {id:"anand",name:"Anand Kumar Sir",org:"Super 30 · Patna",emoji:"🏆",color:"#f59e0b",rgb:"245,158,11",g1:"#f59e0b",g2:"#d97706",style:"Zero-to-hero, motivational 🌟",tag:"Super 30 Legend",tagline:"Garib ho ya ameer — Math sabke liye equal! 🏆",welcome:"Super 30 ka style — basics se shuru karke IIT tak!",ph:"Anand Sir se Math poochho...",qs:[["🏆","Quadratic equations basics"],["📐","Trigonometry identities"],["🌟","Calculus introduction"],["💡","Geometry problems"]],prompt:(l,c,d)=>`You are Anand Kumar Sir AI — Super 30 Patna motivational Math. Start "Namaskar! 🏆 Mathematics mein swagat!" HIGHLY motivational. Always start from FUNDAMENTALS. Real-life applications. End "Samajh aaya? IIT door nahi! 🏆". Level:${d==="easy"?" Basic/CBSE":d==="mains"?" JEE Mains":" JEE Advanced"}${c}\nLANG:${l==="hi"?" ENTIRELY Hindi Devanagari.":" Motivational Hinglish."}`},
    {id:"gt",name:"GT Sir",org:"Allen Kota",emoji:"📐",color:"#3b82f6",rgb:"59,130,246",g1:"#3b82f6",g2:"#2563eb",style:"Deep concepts, calculus master 🔢",tag:"Allen Calculus",tagline:"Calculus aur Algebra — Allen style! 📐",welcome:"Allen Kota ka style — deep conceptual IIT-JEE Math!",ph:"GT Sir se IIT-JEE Math poochho...",qs:[["📐","Limits continuity"],["∫","Integration techniques"],["📊","Conic sections"],["🔢","Matrices determinants"]],prompt:(l,c,d)=>`You are GT Sir AI — Allen Kota Mathematics deep conceptual. Start "Hello students! 📐". WHY before HOW. Multiple methods. Graphical insight. End "Crystal clear? Ab variations! 📐". Level:${d==="easy"?" Foundation":d==="mains"?" JEE Mains":" JEE Advanced rigorous"}${c}\nLANG:${l==="hi"?" ENTIRELY Hindi Devanagari.":" Precise Hinglish."}`},
    {id:"pj",name:"Pankaj Joshi Sir",org:"Unacademy",emoji:"⚡",color:"#8b5cf6",rgb:"139,92,246",g1:"#8b5cf6",g2:"#6d28d9",style:"Speed tricks, shortcuts 🎯",tag:"Unacademy Tricks",tagline:"Speed + Accuracy = JEE Mains! ⚡",welcome:"Shortcuts aur speed — JEE Mains mein time management sabse important!",ph:"Pankaj Sir se tricks poochho...",qs:[["⚡","Trig fastest shortcuts"],["🎯","Integration best tricks"],["🔥","Probability quick methods"],["💫","Complex numbers shortcut"]],prompt:(l,c,d)=>`You are Pankaj Joshi Sir AI — Unacademy Math speed tricks. Start "Hey! ⚡ Speed aur accuracy!". "Normal method 5 min — yeh trick 30 sec! ⚡". Pattern recognition. End "Speed practice karo! ⚡". Level:${d==="easy"?" Basic tricks":d==="mains"?" JEE Mains shortcuts":" Advanced shortcuts"}${c}\nLANG:${l==="hi"?" ENTIRELY Hindi Devanagari.":" Fast energetic Hinglish."}`},
    {id:"sd",name:"Sachin Sir",org:"Physics Wallah",emoji:"📗",color:"#10b981",rgb:"16,185,129",g1:"#10b981",g2:"#059669",style:"CBSE + JEE step-by-step 🧠",tag:"PW CBSE+JEE",tagline:"CBSE se JEE tak — step by step! 📗",welcome:"Har topic clearly samjhaunga — CBSE boards ho ya JEE!",ph:"Sachin Sir se Math poochho...",qs:[["📗","Class 12 Calculus step by step"],["📊","Statistics probability"],["🔢","Algebra CBSE+JEE"],["📐","Coordinate geometry"]],prompt:(l,c,d)=>`You are Sachin Dahiya Sir AI — PW Math systematic CBSE+JEE. Start "Hello! 📗 Systematically samjhate hain!". Systematic numbered steps. Both CBSE+JEE. End "Boards aur JEE dono mein kaam aayega! 📗". Level:${d==="easy"?" CBSE Board":d==="mains"?" JEE Mains":" JEE Advanced"}${c}\nLANG:${l==="hi"?" ENTIRELY Hindi Devanagari.":" Clear friendly Hinglish."}`},
    {id:"aman",name:"Aman Sir",org:"Apni Kaksha",emoji:"🚀",color:"#ef4444",rgb:"239,68,68",g1:"#ef4444",g2:"#dc2626",style:"Young, energetic, fun 💪",tag:"Apni Kaksha",tagline:"Apni Kaksha — Free education for all! 🚀",welcome:"Young, energetic, relatable! Class 10-12 Math fun banate hain!",ph:"Aman Sir se Math poochho...",qs:[["🚀","Quadratic equations fun way"],["🎮","Trigonometry easy"],["💥","Derivatives kya hain?"],["🌈","Probability real life"]],prompt:(l,c,d)=>`You are Aman Dhattarwal Sir AI — Apni Kaksha fun energetic. Start "Hey guys! 🚀". Young relatable. Pop culture examples. Fun emojis. "Tum sab genius ho!". End "Easy tha na? 🚀". Level:${d==="easy"?" Class 10-12":d==="mains"?" JEE Mains basics":" JEE Advanced simply"}${c}\nLANG:${l==="hi"?" ENTIRELY Hindi Devanagari.":" Fun energetic Hinglish."}`},
  ],
};

/* ══════════════════════════════════
   MAIN APP COMPONENT
══════════════════════════════════ */
export default function PCMGuruAI() {
  const [screen, setScreen] = useState("subject");
  const [selectedSubject, setSelectedSubject] = useState(null);
  const [selectedTeacher, setSelectedTeacher] = useState(null);
  const [lang, setLangState] = useState("en");
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [difficulty, setDifficulty] = useState("easy");
  const [toolbarOpen, setToolbarOpen] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [history, setHistory] = useState(() => {
    try { return JSON.parse(localStorage.getItem("pcm_guru_v1") || "[]"); } catch { return []; }
  });
  const [currentChatId, setCurrentChatId] = useState(() => "chat_" + Date.now());
  const chatRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    if (chatRef.current) chatRef.current.scrollTop = chatRef.current.scrollHeight;
  }, [messages]);

  const saveHistory = (msgs, chatId, subj, tchr) => {
    if (!msgs.length) return;
    const first = msgs.find(m => m.role === "user");
    const title = first ? first.content.substring(0, 50) : "New Chat";
    const newChat = {
      id: chatId, title, subject: subj.id, subjectIcon: subj.icon,
      teacher: tchr.id, teacherEmoji: tchr.emoji, teacherColor: tchr.color,
      teacherName: tchr.name, lang, updatedAt: Date.now(), msgs: msgs.slice(-30)
    };
    const updated = [newChat, ...history.filter(c => c.id !== chatId)].slice(0, 40);
    setHistory(updated);
    try { localStorage.setItem("pcm_guru_v1", JSON.stringify(updated)); } catch {}
  };

  const loadChat = (chat) => {
    const s = SUBJECTS[chat.subject];
    const t = TEACHERS[chat.subject]?.find(x => x.id === chat.teacher);
    if (!s || !t) return;
    setSelectedSubject(s); setSelectedTeacher(t);
    setMessages(chat.msgs || []);
    setCurrentChatId(chat.id);
    setScreen("app"); setSidebarOpen(false);
  };

  const startNewChat = () => {
    if (messages.length && selectedSubject && selectedTeacher)
      saveHistory(messages, currentChatId, selectedSubject, selectedTeacher);
    setMessages([]); setCurrentChatId("chat_" + Date.now()); setToolbarOpen(false);
  };

  /* ── KEY CHANGE: fetch goes to /api/claude (Netlify proxy) ── */
  const sendMessage = async () => {
    if (!input.trim() || loading) return;
    const userMsg = input.trim(); setInput(""); setLoading(true); setToolbarOpen(false);
    const newMessages = [...messages, { role: "user", content: userMsg }];
    setMessages(newMessages);
    try {
      let ctx = "";
      const systemPrompt = selectedSubject.id === "mat"
        ? selectedTeacher.prompt(lang, ctx, difficulty)
        : selectedTeacher.prompt(lang, ctx);

      const res = await fetch("/api/claude", {           // ← Changed from direct Anthropic URL
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          system: systemPrompt,
          messages: newMessages
        }),
      });
      const data = await res.json();
      const reply = (data.content || []).filter(b => b.type === "text").map(b => b.text).join("\n");
      const finalMsgs = [...newMessages, { role: "assistant", content: reply || "⚠️ Kuch problem. Dobara try karo!" }];
      setMessages(finalMsgs);
      saveHistory(finalMsgs, currentChatId, selectedSubject, selectedTeacher);
    } catch {
      setMessages([...newMessages, { role: "assistant", content: "⚠️ Error aaya. Dobara try karo!" }]);
    }
    setLoading(false); inputRef.current?.focus();
  };

  const tc = selectedTeacher?.color || "#f59e0b";
  const tg = selectedTeacher
    ? `linear-gradient(135deg,${selectedTeacher.g1},${selectedTeacher.g2})`
    : "linear-gradient(135deg,#f59e0b,#d97706)";

  const S = {
    app: { background: "#07090f", height: "100vh", display: "flex", flexDirection: "column", fontFamily: "'IBM Plex Sans', sans-serif", color: "#e8eaf5", overflow: "hidden", position: "relative" },
    screen: { position: "fixed", inset: 0, zIndex: 300, background: "linear-gradient(135deg,#04060e,#07091a 50%,#04060e)", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: "20px", overflowY: "auto" },
  };

  /* ══════════ SCREEN 1: SUBJECT ══════════ */
  if (screen === "subject") return (
    <div style={S.screen}>
      <div style={{ textAlign: "center", marginBottom: 28 }}>
        <div style={{ fontSize: "3rem", display: "inline-block", animation: "bob 2s ease-in-out infinite", marginBottom: 10 }}>🎓</div>
        <h1 style={{ fontFamily: "'DM Serif Display', serif", fontSize: "2rem", background: "linear-gradient(90deg,#38bdf8,#10b981,#f59e0b)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text", marginBottom: 6 }}>PCM Guru AI</h1>
        <p style={{ fontFamily: "monospace", fontSize: ".62rem", color: "#5a6a8a", letterSpacing: ".1em", textTransform: "uppercase" }}>Physics · Chemistry · Mathematics · IIT-JEE · NEET</p>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 14, maxWidth: 560, width: "100%", marginBottom: 20 }}>
        {Object.values(SUBJECTS).map(s => (
          <button key={s.id} onClick={() => { setSelectedSubject(s); setScreen("teacher"); }}
            style={{ background: `linear-gradient(145deg,rgba(${s.rgb},.12),rgba(${s.rgb},.04))`, border: `1px solid rgba(${s.rgb},.3)`, borderRadius: 16, padding: "20px 12px", cursor: "pointer", textAlign: "center", transition: "all .2s", color: "#e8eaf5" }}
            onMouseOver={e => { e.currentTarget.style.transform = "translateY(-4px)"; e.currentTarget.style.borderColor = `rgba(${s.rgb},.7)`; }}
            onMouseOut={e => { e.currentTarget.style.transform = "translateY(0)"; e.currentTarget.style.borderColor = `rgba(${s.rgb},.3)`; }}>
            <div style={{ fontSize: "2rem", marginBottom: 8 }}>{s.icon}</div>
            <div style={{ fontWeight: 700, fontSize: ".9rem", color: s.color, marginBottom: 3 }}>{s.name}</div>
            <div style={{ fontSize: ".65rem", color: "#4a5a7a" }}>{s.hindiName}</div>
          </button>
        ))}
      </div>
      <p style={{ fontSize: ".7rem", color: "#2a3a5a", marginTop: 8 }}>Apna subject chunoo aur guru se seekho 🚀</p>

      {history.length > 0 && (
        <div style={{ maxWidth: 560, width: "100%", marginTop: 24 }}>
          <p style={{ fontSize: ".7rem", color: "#3a4a6a", marginBottom: 10, textAlign: "center", letterSpacing: ".05em", textTransform: "uppercase" }}>Recent Chats</p>
          <div style={{ display: "flex", flexDirection: "column", gap: 8, maxHeight: 200, overflowY: "auto" }}>
            {history.slice(0, 5).map(chat => (
              <button key={chat.id} onClick={() => loadChat(chat)}
                style={{ background: "rgba(255,255,255,.03)", border: "1px solid rgba(255,255,255,.07)", borderRadius: 10, padding: "10px 14px", cursor: "pointer", textAlign: "left", display: "flex", alignItems: "center", gap: 10, color: "#e8eaf5" }}>
                <span style={{ fontSize: "1.1rem" }}>{chat.teacherEmoji}</span>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: ".78rem", fontWeight: 600, color: chat.teacherColor, marginBottom: 2, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{chat.teacherName}</div>
                  <div style={{ fontSize: ".68rem", color: "#4a5a7a", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{chat.title}</div>
                </div>
                <span style={{ fontSize: ".6rem", color: "#2a3a5a" }}>{chat.subjectIcon}</span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );

  /* ══════════ SCREEN 2: TEACHER ══════════ */
  if (screen === "teacher") {
    const s = selectedSubject;
    const teachers = TEACHERS[s.id] || [];
    return (
      <div style={S.screen}>
        <button onClick={() => setScreen("subject")}
          style={{ position: "absolute", top: 20, left: 20, background: "rgba(255,255,255,.06)", border: "1px solid rgba(255,255,255,.1)", borderRadius: 10, padding: "8px 14px", cursor: "pointer", color: "#8a9abf", fontSize: ".8rem" }}>
          ← Back
        </button>
        <div style={{ textAlign: "center", marginBottom: 24 }}>
          <div style={{ fontSize: "2.2rem", marginBottom: 8 }}>{s.icon}</div>
          <h2 style={{ fontFamily: "'DM Serif Display', serif", fontSize: "1.5rem", color: s.color, marginBottom: 4 }}>{s.name}</h2>
          <p style={{ fontSize: ".7rem", color: "#3a4a6a" }}>{s.tag}</p>
        </div>

        {s.hasLevels && (
          <div style={{ display: "flex", gap: 8, marginBottom: 20 }}>
            {[["easy","🌱 Easy"],["mains","🎯 JEE Mains"],["advanced","⚔️ Advanced"]].map(([v,l]) => (
              <button key={v} onClick={() => setDifficulty(v)}
                style={{ padding: "7px 14px", borderRadius: 20, border: `1px solid ${difficulty===v ? s.color : "rgba(255,255,255,.1)"}`, background: difficulty===v ? `rgba(${s.rgb},.2)` : "transparent", color: difficulty===v ? s.color : "#6a7a9a", fontSize: ".72rem", cursor: "pointer", fontWeight: difficulty===v ? 700 : 400 }}>
                {l}
              </button>
            ))}
          </div>
        )}

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(240px,1fr))", gap: 12, maxWidth: 620, width: "100%" }}>
          {teachers.map(t => (
            <button key={t.id} onClick={() => {
              setSelectedTeacher(t); setMessages([{ role: "assistant", content: `${t.tagline}\n\n${t.welcome}` }]);
              setCurrentChatId("chat_" + Date.now()); setScreen("app");
            }}
              style={{ background: `linear-gradient(145deg,rgba(${t.rgb},.1),rgba(${t.rgb},.03))`, border: `1px solid rgba(${t.rgb},.25)`, borderRadius: 14, padding: "16px", cursor: "pointer", textAlign: "left", transition: "all .2s", color: "#e8eaf5" }}
              onMouseOver={e => { e.currentTarget.style.transform = "translateY(-3px)"; e.currentTarget.style.borderColor = `rgba(${t.rgb},.6)`; }}
              onMouseOut={e => { e.currentTarget.style.transform = "translateY(0)"; e.currentTarget.style.borderColor = `rgba(${t.rgb},.25)`; }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 8 }}>
                <span style={{ fontSize: "1.5rem" }}>{t.emoji}</span>
                <div>
                  <div style={{ fontWeight: 700, color: t.color, fontSize: ".88rem" }}>{t.name}</div>
                  <div style={{ fontSize: ".62rem", color: "#3a4a6a" }}>{t.org}</div>
                </div>
              </div>
              <div style={{ fontSize: ".68rem", color: "#5a6a8a", lineHeight: 1.5 }}>{t.style}</div>
              <div style={{ marginTop: 8, fontSize: ".6rem", background: `rgba(${t.rgb},.15)`, color: t.color, padding: "3px 8px", borderRadius: 20, display: "inline-block" }}>{t.tag}</div>
            </button>
          ))}
        </div>
      </div>
    );
  }

  /* ══════════ SCREEN 3: CHAT APP ══════════ */
  const t = selectedTeacher;
  const s = selectedSubject;

  const renderMsg = (content) => {
    const lines = content.split("\n");
    return lines.map((line, i) => {
      let parts = []; let rest = line; let key = 0;
      while (rest) {
        const bold = rest.match(/\*\*(.+?)\*\*/);
        const code = rest.match(/`(.+?)`/);
        if (!bold && !code) { parts.push(<span key={key++}>{rest}</span>); break; }
        const bi = bold ? rest.indexOf(bold[0]) : Infinity;
        const ci = code ? rest.indexOf(code[0]) : Infinity;
        if (bi < ci) {
          if (bi > 0) parts.push(<span key={key++}>{rest.slice(0, bi)}</span>);
          parts.push(<strong key={key++} style={{ color: tc, fontWeight: 700 }}>{bold[1]}</strong>);
          rest = rest.slice(bi + bold[0].length);
        } else {
          if (ci > 0) parts.push(<span key={key++}>{rest.slice(0, ci)}</span>);
          parts.push(<code key={key++} style={{ background: "rgba(255,255,255,.1)", padding: "1px 5px", borderRadius: 4, fontFamily: "monospace", fontSize: ".85em" }}>{code[1]}</code>);
          rest = rest.slice(ci + code[0].length);
        }
      }
      return <div key={i} style={{ minHeight: line ? undefined : "0.7em" }}>{parts}</div>;
    });
  };

  return (
    <div style={S.app}>
      {/* Sidebar */}
      {sidebarOpen && (
        <div style={{ position: "fixed", inset: 0, zIndex: 200, display: "flex" }}>
          <div style={{ width: 280, background: "#0a0d18", borderRight: "1px solid rgba(255,255,255,.07)", display: "flex", flexDirection: "column", height: "100%" }}>
            <div style={{ padding: "16px 14px", borderBottom: "1px solid rgba(255,255,255,.06)", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <span style={{ fontSize: ".8rem", fontWeight: 700, color: "#8a9abf" }}>Chat History</span>
              <button onClick={() => setSidebarOpen(false)} style={{ background: "none", border: "none", color: "#4a5a7a", cursor: "pointer", fontSize: "1.1rem" }}>✕</button>
            </div>
            <button onClick={() => { startNewChat(); setSidebarOpen(false); setScreen("subject"); }}
              style={{ margin: 12, padding: "10px", background: `rgba(${t?.rgb || "245,158,11"},.15)`, border: `1px solid rgba(${t?.rgb || "245,158,11"},.3)`, borderRadius: 10, color: tc, cursor: "pointer", fontSize: ".78rem", fontWeight: 600 }}>
              + New Chat
            </button>
            <div style={{ flex: 1, overflowY: "auto", padding: "0 8px 8px" }}>
              {history.map(chat => (
                <button key={chat.id} onClick={() => loadChat(chat)}
                  style={{ width: "100%", background: chat.id === currentChatId ? "rgba(255,255,255,.06)" : "transparent", border: "none", borderRadius: 8, padding: "10px 10px", cursor: "pointer", textAlign: "left", color: "#e8eaf5", marginBottom: 2 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <span style={{ fontSize: ".9rem" }}>{chat.teacherEmoji}</span>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: ".7rem", fontWeight: 600, color: chat.teacherColor, marginBottom: 1 }}>{chat.teacherName}</div>
                      <div style={{ fontSize: ".65rem", color: "#3a4a6a", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{chat.title}</div>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>
          <div style={{ flex: 1, background: "rgba(0,0,0,.5)" }} onClick={() => setSidebarOpen(false)} />
        </div>
      )}

      {/* Header */}
      <div style={{ background: "rgba(7,9,15,.95)", borderBottom: "1px solid rgba(255,255,255,.06)", padding: "10px 16px", display: "flex", alignItems: "center", gap: 10, flexShrink: 0 }}>
        <button onClick={() => setSidebarOpen(true)} style={{ background: "none", border: "none", color: "#4a5a7a", cursor: "pointer", fontSize: "1.1rem", padding: "4px" }}>☰</button>
        <div style={{ width: 36, height: 36, borderRadius: "50%", background: tg, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "1rem", flexShrink: 0 }}>{t?.emoji}</div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontWeight: 700, fontSize: ".85rem", color: tc }}>{t?.name}</div>
          <div style={{ fontSize: ".62rem", color: "#3a4a6a", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{t?.org} · {s?.name}</div>
        </div>
        <div style={{ display: "flex", gap: 6 }}>
          {["en","hi"].map(l => (
            <button key={l} onClick={() => setLangState(l)}
              style={{ padding: "4px 10px", borderRadius: 14, border: `1px solid ${lang===l ? tc : "rgba(255,255,255,.1)"}`, background: lang===l ? `rgba(${t?.rgb},.2)` : "transparent", color: lang===l ? tc : "#4a5a7a", fontSize: ".65rem", cursor: "pointer", fontWeight: lang===l ? 700 : 400 }}>
              {l === "en" ? "HIN" : "हिं"}
            </button>
          ))}
          <button onClick={() => setScreen("subject")}
            style={{ padding: "4px 10px", borderRadius: 14, border: "1px solid rgba(255,255,255,.1)", background: "transparent", color: "#4a5a7a", fontSize: ".65rem", cursor: "pointer" }}>
            Switch
          </button>
        </div>
      </div>

      {/* Messages */}
      <div ref={chatRef} style={{ flex: 1, overflowY: "auto", padding: "16px", display: "flex", flexDirection: "column", gap: 12 }}>
        {messages.map((m, i) => (
          <div key={i} style={{ display: "flex", justifyContent: m.role === "user" ? "flex-end" : "flex-start" }}>
            {m.role === "assistant" && (
              <div style={{ width: 28, height: 28, borderRadius: "50%", background: tg, display: "flex", alignItems: "center", justifyContent: "center", fontSize: ".8rem", flexShrink: 0, marginRight: 8, marginTop: 2 }}>{t?.emoji}</div>
            )}
            <div style={{
              maxWidth: "80%", padding: "10px 14px", borderRadius: m.role === "user" ? "16px 16px 4px 16px" : "4px 16px 16px 16px",
              background: m.role === "user" ? `linear-gradient(135deg,rgba(${t?.rgb},.3),rgba(${t?.rgb},.15))` : "rgba(255,255,255,.04)",
              border: m.role === "user" ? `1px solid rgba(${t?.rgb},.4)` : "1px solid rgba(255,255,255,.07)",
              fontSize: ".83rem", lineHeight: 1.65, color: "#d8daf0"
            }}>
              {renderMsg(m.content)}
            </div>
          </div>
        ))}
        {loading && (
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{ width: 28, height: 28, borderRadius: "50%", background: tg, display: "flex", alignItems: "center", justifyContent: "center", fontSize: ".8rem" }}>{t?.emoji}</div>
            <div style={{ display: "flex", gap: 4 }}>
              {[0,1,2].map(i => <div key={i} style={{ width: 7, height: 7, borderRadius: "50%", background: tc, animation: `bob .8s ease-in-out ${i*.2}s infinite` }} />)}
            </div>
          </div>
        )}
      </div>

      {/* Quick actions toolbar */}
      {toolbarOpen && (
        <div style={{ background: "rgba(7,9,15,.98)", borderTop: "1px solid rgba(255,255,255,.06)", padding: "10px 12px", display: "flex", flexWrap: "wrap", gap: 6 }}>
          {s?.actions?.map(a => (
            <button key={a.label} onClick={() => { setInput(a.q); setToolbarOpen(false); setTimeout(() => inputRef.current?.focus(), 50); }}
              style={{ padding: "6px 12px", borderRadius: 18, border: `1px solid rgba(${t?.rgb},.3)`, background: `rgba(${t?.rgb},.1)`, color: tc, fontSize: ".7rem", cursor: "pointer" }}>
              {a.label}
            </button>
          ))}
          {s?.topics?.map((topic, i) => (
            <button key={topic} onClick={() => { setInput(`${topic} samjhao`); setToolbarOpen(false); setTimeout(() => inputRef.current?.focus(), 50); }}
              style={{ padding: "6px 12px", borderRadius: 18, border: "1px solid rgba(255,255,255,.08)", background: "rgba(255,255,255,.04)", color: "#6a7a9a", fontSize: ".7rem", cursor: "pointer" }}>
              {s.topicIcons[i]} {topic}
            </button>
          ))}
        </div>
      )}

      {/* Input */}
      <div style={{ background: "rgba(7,9,15,.98)", borderTop: "1px solid rgba(255,255,255,.06)", padding: "12px 14px", display: "flex", gap: 8, alignItems: "flex-end" }}>
        <button onClick={() => setToolbarOpen(!toolbarOpen)}
          style={{ width: 36, height: 36, borderRadius: 10, background: toolbarOpen ? `rgba(${t?.rgb},.2)` : "rgba(255,255,255,.05)", border: `1px solid ${toolbarOpen ? `rgba(${t?.rgb},.4)` : "rgba(255,255,255,.1)"}`, color: toolbarOpen ? tc : "#4a5a7a", cursor: "pointer", fontSize: ".9rem", flexShrink: 0 }}>
          ⚡
        </button>
        <textarea
          ref={inputRef}
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); } }}
          placeholder={t?.ph || "Sawaal poochho..."}
          rows={1}
          style={{ flex: 1, background: "rgba(255,255,255,.05)", border: "1px solid rgba(255,255,255,.1)", borderRadius: 12, padding: "10px 12px", color: "#e8eaf5", fontSize: ".83rem", fontFamily: "'IBM Plex Sans', sans-serif", resize: "none", outline: "none", lineHeight: 1.5, maxHeight: 120, overflowY: "auto" }}
        />
        <button onClick={sendMessage} disabled={loading || !input.trim()}
          style={{ width: 36, height: 36, borderRadius: 10, background: loading || !input.trim() ? "rgba(255,255,255,.05)" : tg, border: "none", color: loading || !input.trim() ? "#2a3a5a" : "#fff", cursor: loading || !input.trim() ? "not-allowed" : "pointer", fontSize: "1rem", flexShrink: 0, transition: "all .2s" }}>
          {loading ? "⏳" : "➤"}
        </button>
      </div>
    </div>
  );
}
