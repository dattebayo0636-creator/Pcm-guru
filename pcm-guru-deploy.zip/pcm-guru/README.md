# PCM Guru AI — Deploy Guide

## Files Overview
```
pcm-guru/
├── index.html                  ← Entry point
├── vite.config.js              ← Build config
├── netlify.toml                ← Netlify settings
├── package.json                ← Dependencies
├── .gitignore
├── src/
│   ├── main.jsx                ← React entry
│   └── App.jsx                 ← Full app (YOUR CODE)
└── netlify/functions/
    └── claude.js               ← API proxy (keeps key safe)
```

---

## Deploy Steps (15 minutes)

### Step 1 — Install Node.js
Download from https://nodejs.org (LTS version)

### Step 2 — Set up project
Open Terminal / Command Prompt:
```bash
cd pcm-guru
npm install
```

### Step 3 — Test locally (optional)
```bash
npm run dev
```
Open http://localhost:5173 in browser

### Step 4 — Push to GitHub
1. Go to https://github.com → New Repository → name it "pcm-guru"
2. Run these commands:
```bash
git init
git add .
git commit -m "PCM Guru AI"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/pcm-guru.git
git push -u origin main
```

### Step 5 — Deploy on Netlify
1. Go to https://netlify.com → Sign up free
2. Click "Add new site" → "Import an existing project"
3. Connect GitHub → Select your "pcm-guru" repo
4. Build settings (auto-detected):
   - Build command: `npm run build`
   - Publish directory: `dist`
5. Click "Deploy site"

### Step 6 — Add your API key (IMPORTANT)
1. In Netlify dashboard → Your site → Site configuration
2. Click "Environment variables"
3. Click "Add a variable"
4. Key: `ANTHROPIC_API_KEY`
5. Value: `sk-ant-your-key-here`
6. Click Save → Trigger a new deploy

### Step 7 — Done! 🎉
Your site will be live at: `https://random-name.netlify.app`
You can set a custom domain in Netlify settings.

---

## Get your Anthropic API key
1. Go to https://console.anthropic.com
2. Sign up / Log in
3. Click "API Keys" → "Create Key"
4. Copy the key starting with `sk-ant-...`

---

## Security Note
Your API key is NEVER exposed to users.
The `netlify/functions/claude.js` file acts as a secure middleman —
users call `/api/claude` on YOUR server, which then calls Anthropic with your key.
